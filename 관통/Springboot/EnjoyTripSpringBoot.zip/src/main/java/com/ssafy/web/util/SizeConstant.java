package com.ssafy.web.util;

public class SizeConstant {

	public final static int LIST_SIZE = 20/4;
	public final static int NAVIGATION_SIZE = 10/2;
	
}
