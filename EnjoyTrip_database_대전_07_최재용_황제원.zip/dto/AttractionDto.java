package com.ssafy.dto;

public class AttractionDto {

}
