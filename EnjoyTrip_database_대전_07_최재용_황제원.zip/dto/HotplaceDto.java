package com.ssafy.dto;

public class HotplaceDto {

}
